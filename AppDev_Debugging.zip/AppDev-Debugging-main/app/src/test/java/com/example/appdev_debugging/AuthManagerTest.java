package com.example.appdev_debugging;

import com.example.appdev_debugging.auth.AuthManager;
import com.example.appdev_debugging.auth.AuthResult;
import com.example.appdev_debugging.data.InMemoryUserRepository;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class AuthManagerTest {
    private AuthManager authManager;

    @Before
    public void setUp() {
        authManager = new AuthManager(new InMemoryUserRepository());
    }

    @Test
    public void registerAndLogin_isCaseInsensitiveForEmail() {
        AuthResult reg = authManager.register("Juan Dela Cruz", "Juan.DelaCruz@Mail.com", "Pass1234", "Pass1234");
        assertTrue(reg.isSuccess());

        AuthResult loginExact = authManager.login("Juan.DelaCruz@Mail.com", "Pass1234");
        assertTrue(loginExact.isSuccess());

        AuthResult loginLower = authManager.login("juan.delacruz@mail.com", "Pass1234");
        assertTrue(loginLower.isSuccess());

        AuthResult duplicate = authManager.register("Juan Dela Cruz", "juan.delacruz@mail.com", "Pass1234", "Pass1234");
        assertFalse(duplicate.isSuccess());
        assertEquals(AuthResult.Field.EMAIL, duplicate.getField());
    }
}